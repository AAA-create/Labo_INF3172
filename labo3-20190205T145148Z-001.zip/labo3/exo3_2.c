#include <signal.h>
#include <stdio.h>
#include <unistd.h> /* pour la fonction alarm */
#include <stdlib.h>

int i='a';
int j;
void traite_alarme() 
{
	printf("caractère suivant: %c \n",i);
	i++;
	signal(SIGALRM,traite_alarme);
	if (i<='z') alarm(1);
	else exit(0);
}
int main()
{
traite_alarme();
while (1);
}

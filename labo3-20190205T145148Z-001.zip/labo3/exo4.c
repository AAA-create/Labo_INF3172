#include <stdio.h>
#include <signal.h>
#include <unistd.h> /* pour la fonction alarm */
#include <stdlib.h>
void Recuperation(int sig)
{
	static compt = 0;
	switch (sig) 
	{
	case SIGSEGV: printf("il s'en est fallu de peu\n");
	/* La seule chose que l'on peut faire ici est de terminer le
	* programme puisqu'on ne sait pas reparer l'erreur. Un simple
	* return provoquerait une boucle
	*/
	exit(1);
	case SIGINT: if (++compt == 5)
		 {
		printf("J'en ai assez!!\n");
		exit(1);
		}
	else
		printf("OK je recupere le signal SIGINT\n");
	}
}
void main()
{
	char t[1];
	int i=0;
	signal(SIGSEGV, Recuperation);
	signal(SIGINT, Recuperation);
	printf("Taper 5 ^C pour arreter le programme ou return pour continuer\n");
	getchar();
	/* On provoque un SIGSEGV car on sort du tableau t */
	while(t[i++] = '!');
} 	

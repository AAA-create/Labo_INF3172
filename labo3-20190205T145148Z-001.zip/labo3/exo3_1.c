// programme qui ignore tous les signaux  (a)
#include <stdio.h>	 
#include <stdlib.h>	
#include <unistd.h>
#include <signal.h>
void Traite_Sig (int Numero) 
{
	printf("Coucou,recu signal %d ! mais je l'ignore !\n",Numero);
	signal (Numero,Traite_Sig);
}

int main() 
{

	int Nb_Sig;
	for (Nb_Sig = 1; Nb_Sig < NSIG ; Nb_Sig++)
	{
	signal (Nb_Sig,Traite_Sig);
	}
	while(1);
	/*Attendre des signaux */
}

#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
int main(void){
pid_t pid_fils[5];
int i;
for(i=0; i<4; i++){
pid_fils[i]=fork();
if(pid_fils[i]==-1){
printf("error" );
exit(1);
}
if(pid_fils[i]==0){
printf("je suis le fils%d\n", i+1);
break;
}
}
return 0;
}

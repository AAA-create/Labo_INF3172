#include "stdio.h"
int main()
{
char *argVec[2];
argVec[0] = "Georges";
argVec[1] = "Debay";
char *envVec[] = { "TEST1=salut", "TEST2=adieu", '\0' };
int x = 0;
x = fork();
if (x == 0)
execve("./fils.exe",argVec , envVec);
}


